package in.amazon.tests;

import org.testng.annotations.Test;

public class ApparelHomepageTest extends BaseTest {

	@Test(priority=0)

	public void SearchProduct() throws Exception {

		/*
		 * String product = "Apple Watch"; String category = "Electronics";
		 * 
		 */

		homepage.searchProduct();
		homepage1.createAccount();
		homepage1.signout();
		homepage1.signin();
		homepage1.serachandorder();
		homepage1.shareproduct();
		homepage1.placingorderone();
		homepage1.placingordertwo();
		

	}
	


}
