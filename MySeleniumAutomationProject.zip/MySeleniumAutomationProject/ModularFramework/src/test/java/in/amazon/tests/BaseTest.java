package in.amazon.tests;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import commonLibs.implementation.CommonDriver;
import in.amazon.pages.ApparelCreateAccount;
import in.amazon.pages.ApparelHomepage;

public class BaseTest {

	CommonDriver cmnDriver;

	ApparelHomepage homepage;
	ApparelCreateAccount homepage1;

	WebDriver driver;

	@BeforeMethod
	public void setup() throws Exception {

		cmnDriver = new CommonDriver("chrome");

		cmnDriver.setPageloadTimeout(90);
		cmnDriver.setElementDetectionTimeout(20);
		cmnDriver.navigateToUrl("http://automationpractice.com/index.php");
		driver = cmnDriver.getDriver();
		homepage = new ApparelHomepage(driver);
		homepage1 = new ApparelCreateAccount(driver);
	}

	@AfterMethod
	public void cleanUp() throws Exception {

		cmnDriver.closeAllBrowsers();
	}

}
