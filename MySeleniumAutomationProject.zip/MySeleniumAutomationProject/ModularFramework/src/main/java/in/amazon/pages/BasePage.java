package in.amazon.pages;

import org.openqa.selenium.WebDriver;

import commonLibs.implementation.AlertControl;
import commonLibs.implementation.CommonDriver;
import commonLibs.implementation.CommonElement;
import commonLibs.implementation.DropdownControl;
import commonLibs.implementation.FrameControl;
import commonLibs.implementation.JavascriptControl;
import commonLibs.implementation.MouseactionControl;
import commonLibs.implementation.WindowControl;

public class BasePage {

	CommonElement elementControl;
	CommonDriver commondriver;
	DropdownControl dropdownControl;
	MouseactionControl mouseControl;
	FrameControl frameControl;
	AlertControl alertcontrol;
	JavascriptControl javascriptcontrol;
	WindowControl windowcontrol;
	
	
	public BasePage(WebDriver driver) {

		elementControl = new CommonElement();
		//commondriver = new CommonDriver();

		dropdownControl = new DropdownControl();

		mouseControl = new MouseactionControl(driver);

		frameControl = new FrameControl(driver);
		alertcontrol = new AlertControl(driver);
		javascriptcontrol = new JavascriptControl(driver);
		windowcontrol = new WindowControl(driver);
	}

}
