package in.amazon.pages;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import commonLibs.implementation.CommonElement;
import commonLibs.implementation.DropdownControl;

public class ApparelCreateAccount extends BasePage {

	@CacheLookup
	@FindBy(name = "email_create")
	private WebElement emailEnter;

	@CacheLookup
	@FindBy(name = "SubmitCreate")
	private WebElement SubmitCreate;

	@CacheLookup
	@FindBy(name = "id_gender")
	private WebElement Title;

	@CacheLookup
	@FindBy(name = "customer_firstname")
	private WebElement FirstName;

	@CacheLookup
	@FindBy(name = "customer_lastname")
	private WebElement LastName;

	@CacheLookup
	@FindBy(name = "passwd")
	private WebElement passwd;

	@CacheLookup
	@FindBy(name = "address1")
	private WebElement Address;

	@CacheLookup
	@FindBy(name = "city")
	private WebElement city;

	@CacheLookup
	@FindBy(name = "postcode")
	private WebElement postcode;

	@CacheLookup
	@FindBy(name = "id_state")
	private WebElement State;

	@CacheLookup
	@FindBy(name = "phone_mobile")
	private WebElement mobilenum;

	@CacheLookup
	@FindBy(name = "submitAccount")
	private WebElement Register;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"header\"]/div[2]/div/div/nav/div[2]/a")
	private WebElement signout;

	@CacheLookup
	@FindBy(className = "login")
	private WebElement signinoption;

	@CacheLookup
	@FindBy(name = "email")
	private WebElement username;

	@CacheLookup
	@FindBy(name = "passwd")
	private WebElement loginpassword;

	@CacheLookup
	@FindBy(name = "SubmitLogin")
	private WebElement loginsubmit;

	@CacheLookup
	@FindBy(name = "search_query")
	private WebElement globalserachdata;

	@CacheLookup
	@FindBy(name = "submit_search")
	private WebElement globalserachsubmit;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"center_column\"]/ul/li[1]/div/div[1]/div/a[1]/img")
	private WebElement productselect;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"product_comments_block_extra\"]/ul/li/a")
	private WebElement writereview;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"criterions_list\"]/li/div[1]/div[6]/a")
	private WebElement reviewrating;

	@CacheLookup
	@FindBy(id = "comment_title")
	private WebElement reviewtitle;

	@CacheLookup
	@FindBy(id = "content")
	private WebElement reviewcomment;

	@CacheLookup
	@FindBy(id = "submitNewMessage")
	private WebElement reviewsubmit;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"product\"]/div[2]/div/div/div/p[2]/button/span")
	private WebElement reviewfinalsubmit;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"center_column\"]/div/div/div[3]/p[7]/button[3]")
	private WebElement GooglePlusShareProduct;
	
	


	// private WebElement searchButton;

	@FindBy(xpath = "//*[@id='header_logo']/a/img")
	private WebElement searchResult;

	public ApparelCreateAccount(WebDriver driver) {

		super(driver);

		PageFactory.initElements(driver, this);

	}

	String myEmailAddress = "username" + System.currentTimeMillis() + "@Gmail.com";
	String mypassword = "username" + System.currentTimeMillis() + "@Gmail.com";

	@Test(priority = 1)

	public void createAccount() throws Exception {

		elementControl.clickElement(emailEnter);
		elementControl.setText(emailEnter, myEmailAddress);
		elementControl.clickElement(SubmitCreate);
		elementControl.clickElement(Title);
		elementControl.setText(FirstName, "FirstName");
		elementControl.setText(LastName, "LastName");
		elementControl.setText(passwd, mypassword);
		elementControl.setText(Address, "TestAddress");
		elementControl.setText(city, "TestCity");
		elementControl.setText(postcode, "12345");
		elementControl.setText(mobilenum, "9898989898");
		dropdownControl.selectViaValue(State, "1");
		elementControl.clickElement(Register);

		boolean actual = elementControl.isElementVisible(signout);
		Assert.assertEquals(actual, true);

	}
	
	@CacheLookup
	@FindBy(xpath = "//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")
	private WebElement signinicon;
	
	

	@Test(priority = 2)

	public void signout() throws Exception {

		elementControl.clickElement(signout);
		
		boolean signiniconverify = elementControl.isElementVisible(signinicon);
		Assert.assertEquals(signiniconverify, true);
	
	}
	
	@CacheLookup
	@FindBy(xpath = "//*[@id=\"my-account\"]")
	private WebElement signinwelcomepage;

	
	@Test(priority = 3)

	public void signin() throws Exception {

		elementControl.clickElement(signinoption);
		elementControl.setText(username, myEmailAddress);
		elementControl.setText(loginpassword, mypassword);
		elementControl.clickElement(loginsubmit);
		
		String welcomepage = elementControl.getText(signinwelcomepage);
		// System.out.println(welcomepage);
		Assert.assertTrue(welcomepage.contains("Welcome to your account. Here you can manage all of your personal information and orders."), "Welcome to your account. Here you can manage all of your personal information and orders.");

	}

	@Test(priority = 4)

	public void serachandorder() throws Exception {

		elementControl.clickElement(globalserachdata);
		elementControl.setText(globalserachdata, "cotton");
		elementControl.clickElement(globalserachsubmit);
		elementControl.clickElement(productselect);
		elementControl.clickElement(writereview);
		windowcontrol.switchToChildWindow(0);
		// elementControl.clickElement(reviewtitle);
		elementControl.clickElement(reviewrating);
		elementControl.setText(reviewtitle, "Awesome eCommerce website");
		elementControl.setText(reviewcomment, "Wonderful eCommerce website");
		elementControl.clickElement(reviewsubmit);
		elementControl.clickElement(reviewfinalsubmit);

	}

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"center_column\"]/div/div/div[3]/p[7]/button[2]")
	private WebElement FacebookShareProduct;

	@CacheLookup
	@FindBy(id = "email")
	private WebElement FacebookUsername;

	@CacheLookup
	@FindBy(id = "pass")
	private WebElement FacebookPassword;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"product\"]")
	private WebElement reviewpage;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"center_column\"]/div/div/div[3]/p[7]/button[4]")
	private WebElement PinterestShareProduct;

	@CacheLookup
	@FindBy(id = "email")
	private WebElement pinemailId;

	@CacheLookup
	@FindBy(id = "password")
	private WebElement pinpassword;

	@Test(priority = 5)

	public void shareproduct() throws Exception {

		// Facebook

		elementControl.clickElement(FacebookShareProduct);
		Set<String> windows = windowcontrol.getWindowHandles();
		String parent = windowcontrol.getWindowHandle();
		windows.remove(parent);
		Iterator<String> it = windows.iterator();
		String child = null;
		while (it.hasNext()) {
			child = (String) it.next();
			windowcontrol.switchToChildWindow(child);
			elementControl.setText(FacebookUsername, "test@gmail.com");
			elementControl.setText(FacebookPassword, "Fbpassword");
			windowcontrol.close();

		}
		windowcontrol.switchToChildWindow(parent);

		String text1 = elementControl.getText(reviewpage);
		// System.out.println(text);
		Assert.assertTrue(text1.contains("Faded Short Sleeve T-shirts"), "Faded Short Sleeve T-shirts");

		// Pinterest

		elementControl.clickElement(PinterestShareProduct);
		Set<String> windows1 = windowcontrol.getWindowHandles();
		String parent1 = windowcontrol.getWindowHandle();
		windows1.remove(parent);
		Iterator<String> it1 = windows1.iterator();
		String child1 = null;
		while (it1.hasNext()) {
			child1 = (String) it1.next();
			windowcontrol.switchToChildWindow(child1);
			elementControl.setText(pinemailId, "test@gmail.com");
			elementControl.setText(pinpassword, "pinpassword");

			boolean actual2 = elementControl.isElementVisible(pinemailId);
			Assert.assertEquals(actual2, true);
			windowcontrol.close();

		}
		windowcontrol.switchToChildWindow(parent1);

		// Google++

		// elementControl.clickElement(GooglePlusShareProduct);

	}

	@CacheLookup
	@FindBy(id = "add_to_cart")
	private WebElement cart;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a")
	private WebElement ProceedToCheckoutone;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"center_column\"]/p[2]/a[1]/span")
	private WebElement ProceedToCheckoutTwo;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"center_column\"]/form/p/button/span")
	private WebElement ProceedToCheckoutThree;

	@CacheLookup
	@FindBy(id = "cgv")
	private WebElement TermsOfService;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"form\"]/p/button/span")
	private WebElement ProceedToCheckoutFour;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"HOOK_PAYMENT\"]/div[1]/div/p/a")
	private WebElement Payment;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"cart_navigation\"]/button/span")
	private WebElement FinalOrder;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"order-confirmation\"]")
	private WebElement ReviewOrder;

	@Test(priority = 6)
	public void placingorderone() throws Exception {

		elementControl.clickElement(cart);
		windowcontrol.switchToChildWindow(0);
		elementControl.clickElement(ProceedToCheckoutone);
		elementControl.clickElement(ProceedToCheckoutTwo);
		elementControl.clickElement(ProceedToCheckoutThree);
		elementControl.clickElement(TermsOfService);
		elementControl.clickElement(ProceedToCheckoutFour);
		elementControl.clickElement(Payment);
		elementControl.clickElement(FinalOrder);

		String text = elementControl.getText(ReviewOrder);
		// System.out.println(text);
		Assert.assertTrue(text.contains("Your order on My Store is complete"), "Your order on My Store is complete");

	}

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"block_top_menu\"]/ul/li[2]/a")
	private WebElement dresscategory;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"center_column\"]/ul/li[1]/div/div[1]/div/a[1]/img")
	private WebElement mouseover;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"center_column\"]/ul/li[1]/div/div[2]/div[2]/a[1]/span")
	private WebElement addtocart;

	/*
	 * @CacheLookup
	 * 
	 * @FindBy(xpath = "//*[@id=\"add_to_cart\"]/button/span") private WebElement
	 * addtocart;
	 */

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a/span")
	private WebElement checkoutone;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"center_column\"]/p[2]/a[1]/span")
	private WebElement checkouttwo;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"center_column\"]/form/p/button/span")
	private WebElement checkoutthree;

	@CacheLookup
	@FindBy(id = "cgv")
	private WebElement tc;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"form\"]/p/button/span")
	private WebElement checkoutfour;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"HOOK_PAYMENT\"]/div[1]/div/p/a")
	private WebElement paymenttwo;

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"cart_navigation\"]/button/span")
	private WebElement confirmorder;

	@Test(priority = 7)

	public void placingordertwo() throws Exception {

		elementControl.clickElement(dresscategory);
		javascriptcontrol.scrolDown(0, 1000);
		mouseControl.moveToElement(mouseover);
		elementControl.clickElement(addtocart);
		windowcontrol.switchToChildWindow(0);
		// elementControl.clickElement(addtocart);

		// windowcontrol.switchToChildWindow(1);
		elementControl.clickElement(checkoutone);
		elementControl.clickElement(checkouttwo);
		elementControl.clickElement(checkoutthree);
		elementControl.clickElement(tc);
		elementControl.clickElement(checkoutfour);
		elementControl.clickElement(paymenttwo);
		elementControl.clickElement(confirmorder);

	}

}
