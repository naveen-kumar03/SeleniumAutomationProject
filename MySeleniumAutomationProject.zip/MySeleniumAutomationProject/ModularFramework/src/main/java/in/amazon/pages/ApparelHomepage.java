package in.amazon.pages;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import commonLibs.implementation.CommonElement;
import commonLibs.implementation.DropdownControl;

public class ApparelHomepage extends BasePage {

	@CacheLookup
	@FindBy(xpath = "//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")
	private WebElement signIn;

	@FindBy(xpath = "//*[@id='header_logo']/a/img")
	private WebElement searchResult;

	public ApparelHomepage(WebDriver driver) {

		super(driver);

		PageFactory.initElements(driver, this);

	}
	
	@Test(priority=0)

	public String searchProduct() throws Exception {

		// elementControl.setText(searchBox, product);

		elementControl.clickElement(signIn);

		// elementControl.clickElement(searchButton);

		String result = elementControl.getText(searchResult);

		return result;

	}

}
