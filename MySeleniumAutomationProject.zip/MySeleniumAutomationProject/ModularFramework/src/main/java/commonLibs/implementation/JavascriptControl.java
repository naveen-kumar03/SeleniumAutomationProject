package commonLibs.implementation;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import commonLibs.contracts.IJavascripts;

public class JavascriptControl implements IJavascripts {
	
	JavascriptExecutor jsEngine;
	
	public JavascriptControl(WebDriver driver) {
		
		jsEngine = (JavascriptExecutor) driver;
	}

	@Override
	public void executeJavaScript(String scriptToExecute) throws Exception {

		jsEngine.executeScript(scriptToExecute);
	}

	@Override
	public void scrolDown(int x, int y) throws Exception {
		
		String jsCommand= String.format("window.scrollBy(%d,%d)", x,y);

		executeJavaScript(jsCommand);
		
	}

	@Override
	public String executeJavaScriptWithReturnValue(String scriptToExecute) throws Exception {

		return jsEngine.executeScript(scriptToExecute).toString();
	}

}
