package commonLibs.contracts;

public interface IScreenshot {

}
