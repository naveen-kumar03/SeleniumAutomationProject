package commonLibs.contracts;

public interface IJavascripts {
	
	public void executeJavaScript(String scriptToExecute) throws Exception;
	public void scrolDown(int x, int y) throws Exception;
	public String executeJavaScriptWithReturnValue(String scriptToExecute) throws Exception;

}
